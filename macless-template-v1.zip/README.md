# Ship an iOS app without a Mac

A working GitHub Actions pipeline that builds, signs, and uploads a
Capacitor-based iOS app to TestFlight — entirely on GitHub's free macOS
runners. No Mac, no rented cloud Mac, no monthly CI bill.

This is the real setup used to ship [Citolex](https://citolex.com) to the
App Store. It's been cleaned up and genericized so you can drop it into
your own project.

## Start here

1. Read **SETUP.md** — the overall path, start to finish.
2. Follow **SIGNING.md** — one-time signing setup, no Xcode required.
3. Copy `.github/workflows/ios-testflight.yml` into your own repo.
4. Push. Watch the Actions tab.
5. When you're ready to actually submit, **APP_STORE_SUBMISSION.md** covers
   the App Store Connect fields that trip people up the first time.
6. If a build fails, check **TROUBLESHOOTING.md** before anything else —
   it covers the actual errors this pipeline hits.

The `advanced/` folder covers adding a Share Extension or custom native
Swift plugin (the way Citolex adds native text-to-speech and a share
sheet). Most apps don't need this — skip it unless you know you do.

## What this assumes

- Your app is a [Capacitor](https://capacitorjs.com) project (a website
  wrapped as a native shell). If you're not using Capacitor, the signing
  and CI steps still apply — you'll just skip the `npx cap` commands and
  point the workflow at your own `.xcworkspace`/`.xcodeproj`.
- You have (or are getting) an Apple Developer Program membership
  ($99/year, unavoidable — this doesn't replace it, it just removes the
  need for a Mac to sign and ship).
- Your repo is public, or you understand the private-repo tradeoff
  covered in SIGNING.md.

## License

Personal-use license — for the person or team who purchased it, on your
own projects. Not for resale or redistribution. If someone you know wants
it, send them to the place you got it rather than forwarding your copy.

Questions before or after buying: localinfine@gmail.com
