# Ship an iOS app without a Mac

A working GitHub Actions pipeline that builds, signs, and uploads a
Capacitor-based iOS app to TestFlight — entirely on GitHub's free macOS
runners. No Mac, no rented cloud Mac, no monthly CI bill.

This is the real setup used to ship [Citolex](https://citolex.com) to the
App Store. It's been cleaned up and genericized so you can drop it into
your own project.

## Start here

1. Read **SETUP.md** — the overall path, start to finish.
2. Follow **SIGNING.md** — one-time signing setup, no Xcode required.
3. Copy `.github/workflows/ios-testflight.yml` into your own repo.
4. Push. Watch the Actions tab.
5. When you're ready to actually submit, **APP_STORE_SUBMISSION.md** covers
   the App Store Connect fields that trip people up the first time.
6. If a build fails, check **TROUBLESHOOTING.md** before anything else —
   it covers the actual errors this pipeline hits.

The `advanced/` folder covers adding a Share Extension or custom native
Swift plugin (the way Citolex adds native text-to-speech and a share
sheet). Most apps don't need this — skip it unless you know you do.

**Don't own an iPhone?** `SIMULATOR_PREVIEW.md` covers a second, optional
workflow that builds an unsigned Simulator version of your app and saves a
screenshot as a build artifact — no signing setup, no Apple hardware, no
extra cost. It's not a replacement for a real-device check before you
submit, but it means you're not flying blind before then. Related:
`.github/workflows/screenshots.yml` does the same thing but at the exact
sizes Apple requires for submission — see APP_STORE_SUBMISSION.md.

The main workflow also includes a **signing validation step** that checks
your provisioning profile's Team ID and bundle ID against your GitHub
secrets/variables before the archive step runs, so a mismatch fails with
a specific, readable reason instead of a generic xcodebuild error buried
in the log.

**Also shipping to Google Play?** `ANDROID.md` +
`.github/workflows/android-build.yml` cover a signed Android App Bundle
build and Play Store upload, structured the same way as the iOS
pipeline. Optional — skip it if you're iOS-only.

All three workflows now cache `node_modules` (and CocoaPods/Gradle where
relevant) between runs, so repeat builds are a bit faster than the first
one. `ios-testflight.yml` also has an optional webhook-notification step
— set a `NOTIFY_WEBHOOK_URL` secret to get a Discord/Slack-style ping on
build success or failure; leave it unset and it's simply skipped.

**Changed something in one of the workflow files?** See TESTING.md for
how to actually run it in a throwaway repo before trusting it, rather
than just reading the YAML and hoping.

Check **CHANGELOG.md** for what's changed since you downloaded this.
Stuck on something not covered above? **SUPPORT.md** has the fastest
paths — including a GitHub Discussions space for this template.

## What this assumes

- Your app is a [Capacitor](https://capacitorjs.com) project (a website
  wrapped as a native shell). If you're not using Capacitor, the signing
  and CI steps still apply — you'll just skip the `npx cap` commands and
  point the workflow at your own `.xcworkspace`/`.xcodeproj`.
- You have (or are getting) an Apple Developer Program membership
  ($99/year, unavoidable — this doesn't replace it, it just removes the
  need for a Mac to sign and ship).
- Your repo is public, or you understand the private-repo tradeoff
  covered in SIGNING.md.

## License

Personal-use license — for the person or team who purchased it, on your
own projects. Not for resale or redistribution. If someone you know wants
it, send them to the place you got it rather than forwarding your copy.

Questions before or after buying: localinfine@gmail.com
