# Troubleshooting

Real problems this pipeline has actually hit, and how to fix each one.
Almost everything at this stage is a signing mismatch — a name or ID that
doesn't line up exactly between Apple's side and GitHub's secrets — rather
than a real code problem.

## Upload "succeeds" but the build never shows up in TestFlight

This is the most confusing failure because the Actions log shows green.
App Store Connect silently rejects re-uploads that reuse the same
marketing version + build number pair — `xcrun altool` reports a
successful *file transfer* either way, so the CI log looks fine while the
build quietly never appears.

Fix: make sure `CURRENT_PROJECT_VERSION` is set to something that changes
every run — the template does this with `${{ github.run_number }}`,
GitHub's own per-workflow run counter. If you've customized the archive
step and dropped this, every push after the first will silently vanish.

## "No signing certificate matching team ID" / codesign errors

Almost always one of:
- The provisioning profile name in your `IOS_PROVISIONING_PROFILE_NAME`
  variable doesn't **exactly** match the name you gave the profile in
  Apple's portal (case-sensitive, whitespace-sensitive).
- The bundle ID in `IOS_BUNDLE_ID` doesn't match the App ID the profile
  was generated for.
- The certificate in `IOS_DIST_CERT_P12_BASE64` has expired, or was
  regenerated in Apple's portal without regenerating the profile that
  references it (profiles pin to a specific certificate).

Check the "Import signing certificate" step's log — it prints the
identities actually found in the keychain, which tells you whether the
cert imported at all before blaming the profile.

**The "Validate signing setup" step (runs right after that one) catches
the Team ID and bundle ID mismatches from the list above automatically**
and fails with the specific mismatch spelled out, before you ever get to
a raw xcodebuild error. If you land here anyway, it's most likely the
third bullet (an expired or regenerated certificate) — that one can't be
checked from the profile alone.

## `npx cap add ios` fails or the App target isn't found

Capacitor's generated project layout occasionally shifts between major
versions. If you're using the `advanced/configure_ios_project.rb` script
and it can't find the `App` target, that's this — paste the exact error
and it's a quick patch against your Capacitor version, not a sign
anything is fundamentally broken.

## Export Compliance blocks TestFlight install

Covered in SETUP.md and APP_STORE_SUBMISSION.md — this is a per-build
question in App Store Connect, not a one-time setting. A build sits
un-installable until someone answers it for that specific build.

## GitHub Actions minutes running out on a private repo

Confirms you're on a private repo — the free-unlimited-macOS-minutes perk
is public-repos-only. See the "Private repos" section at the bottom of
SIGNING.md for the actual numbers and what it costs past the free tier.

## Still stuck

Email localinfine@gmail.com with the failed run's log (the Actions tab
has a "Download log" option) — these builds fail specifically enough that
most issues are diagnosable from the log alone.
