# Changelog

What's changed in the template since you bought it. There's no
automated update notification yet (see the note at the bottom) — the
most reliable way to check is comparing this file's dates against when
you last downloaded, and re-grabbing `macless-template-v1.zip` from the
same link in your original purchase confirmation if anything below looks
relevant to you.

## 2026-08-17

- Added `.github/workflows/screenshots.yml` — generates the two
  screenshot sizes Apple actually requires at submission time (6.9"
  iPhone, 13" iPad), by running the Simulator at those exact device
  classes.
- **Fixed a real bug** in `simulator-preview.yml` and `screenshots.yml`:
  the `.app` product lookup used the wrong search depth and could report
  "No .app product found" even after a fully successful build. Both
  workflows are now live-tested end to end, not just reviewed — see
  TESTING.md for how.
- Added `ANDROID.md` + `.github/workflows/android-build.yml` — a signed
  Android App Bundle build and Google Play upload, structured the same
  way as the iOS pipeline. (Reviewed carefully, not yet live-tested —
  see the Status section in ANDROID.md.)
- Added optional build caching (`actions/cache`) to all the workflows —
  faster repeat runs, no behavior change if a cache key ever misses.
- Added an optional webhook notification step to `ios-testflight.yml` —
  posts build success/failure to a Discord- or Slack-compatible webhook
  if you set a `NOTIFY_WEBHOOK_URL` secret; does nothing if you don't.
- Added `scripts/generate_signing_secrets.sh` — an interactive script
  that walks through SIGNING.md's certificate/profile generation and
  writes the base64 values straight to files, instead of copy-pasting
  each `openssl` command by hand.
- Added `TESTING.md` — how to live-test a workflow change in a
  throwaway repo before trusting it, using the exact process that caught
  the bug above.
- Added `SUPPORT.md` — where to ask if you get stuck, including a new
  GitHub Discussions space.

## 2026-08-16

- **Fixed a critical packaging bug:** the product zip was missing
  `.github/workflows/ios-testflight.yml` — the actual pipeline — even
  though SETUP.md told you to copy it in. If you bought before this date
  and hit a dead end at that step, re-download the zip from your
  original purchase confirmation link; it's fixed now.
- Added `.github/workflows/simulator-preview.yml` — build and
  screenshot your app in the iOS Simulator, no signing setup or Apple
  hardware required.
- Added a "Validate signing setup" step to `ios-testflight.yml` — checks
  your provisioning profile's Team ID and bundle ID against your GitHub
  secrets/variables before the archive step, so a mismatch fails with a
  specific reason instead of a generic Xcode error buried in the log.
- Fixed an `ADVANCED.md` doc bug (referenced placeholder names that
  didn't match the actual script's constants).

## Earlier

- Initial release: `ios-testflight.yml`, `SIGNING.md`, `SETUP.md`,
  `APP_STORE_SUBMISSION.md`, `TROUBLESHOOTING.md`, `advanced/` (Share
  Extension / native plugin support).

---

**On update notifications:** there's no mailing list today — Stripe's
post-payment page hands you a direct download link with no follow-up
email. Stripe does record every buyer's email on the payment itself, so
a manual one-off "here's what's new" email to past buyers (exported from
the Stripe dashboard's customer list) is possible any time it's worth
doing — that's a decision/action for Jackson to make from Stripe
directly, not something this file automates.
