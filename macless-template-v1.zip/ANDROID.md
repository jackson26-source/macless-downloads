# Android / Google Play setup (optional)

This is the Android equivalent of SIGNING.md — one-time setup so
`.github/workflows/android-build.yml` can build a signed `.aab` and
upload it to Google Play automatically. Skip this file entirely if
you're only shipping to the App Store.

Runs on a standard Ubuntu GitHub Actions runner (not macOS) — faster and
well within GitHub's free minutes even on a private repo, since Android
builds don't need the 10x macOS-runner multiplier iOS builds do.

## 1. Create a signing keystore

```
keytool -genkey -v -keystore release.keystore -alias upload -keyalg RSA -keysize 2048 -validity 10000
```

Keep `release.keystore` somewhere safe — if you lose it, you lose the
ability to publish updates to your app under the same Play Store listing.
`keytool` ships with any JDK. If you don't have one installed locally,
this can also be generated once on a GitHub-hosted runner and downloaded
as a build artifact instead — ask if you'd rather do it that way.

Base64-encode it the same way SIGNING.md does for iOS certificates:

```
openssl base64 -in release.keystore -out release_keystore_base64.txt -A
```

## 2. Register the app in Google Play Console

Go to [Google Play Console](https://play.google.com/console) → Create app
→ fill in the basics → pick your package name (e.g.
`com.yourname.yourapp`, matching what's in `capacitor.config.json`).
Google Play requires at least one manual release through the console for
a brand-new app before it accepts API uploads — do that first release by
hand, then this workflow takes over for every one after.

## 3. Create a Play Console service account

1. Play Console → **Setup → API access** → link (or create) a Google
   Cloud project if you don't already have one → **Create new service
   account**
2. Follow the link into Google Cloud Console, create the service
   account, generate a JSON key, download it
3. Back in Play Console, grant that service account **Release manager**
   permission (or a custom role with release + app-info access) for your
   specific app

## 4. Add secrets and variables to your GitHub repo

**Settings → Secrets and variables → Actions.**

Repository secrets:

| Secret name | Value |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | base64 of `release.keystore` |
| `ANDROID_KEYSTORE_PASSWORD` | the password you set with `keytool` |
| `ANDROID_KEY_ALIAS` | the `-alias` value you used (e.g. `upload`) |
| `ANDROID_KEY_PASSWORD` | usually the same as the keystore password unless you set a separate one |
| `ANDROID_PLAY_SERVICE_ACCOUNT_JSON` | the full contents of the service account JSON file from step 3 |

Repository variables:

| Variable name | Value |
|---|---|
| `ANDROID_PACKAGE_NAME` | your package name, e.g. `com.yourname.yourapp` |
| `ANDROID_PLAY_TRACK` | `internal`, `alpha`, `beta`, or `production` — defaults to `internal` if you leave this unset, which is where you should start anyway |

## How this differs structurally from the iOS pipeline

The iOS workflow signs by passing flags straight to `xcodebuild`. This
one works the same way in spirit but at a different layer: the build
produces an **unsigned** `.aab` via `./gradlew bundleRelease`, then a
separate step signs that file directly with `jarsigner`. Nothing about
signing is ever written into the Capacitor-generated `android/` project
itself — same reasoning as the iOS side, since `npx cap add android`
regenerates that project from scratch on every run.

## Status

This workflow has been reviewed line by line but **not run end-to-end** —
doing that needs a real Google Play Console app and service account,
which isn't something this template can test on its own the way the
zero-signing Simulator/screenshot workflows could be. Treat it as a
solid, carefully-reasoned starting point, not a proven pipeline, until
you've run it once yourself. If a step doesn't line up with Play
Console's current flow, email localinfine@gmail.com and it'll get fixed
for everyone.

## Still stuck

Email localinfine@gmail.com — same as the iOS side. See also SUPPORT.md.
