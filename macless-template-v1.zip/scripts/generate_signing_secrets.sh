#!/usr/bin/env bash
#
# Walks through the copy-paste-heavy parts of SIGNING.md interactively
# and writes the exact base64 values you'll paste into GitHub's Secrets
# and variables UI. It doesn't touch your Apple or GitHub accounts, and
# it doesn't upload anything anywhere — it only saves you handling
# openssl and base64 by hand. You still do the parts that require
# clicking around Apple's own websites (creating the certificate,
# profile, App ID, and API key); this script just handles the
# command-line half before and after each of those.
#
# Works on macOS and Linux out of the box. On Windows, run it through
# Git Bash (same as the manual openssl commands in SIGNING.md).
#
set -euo pipefail

OUT_DIR="secrets_output"
mkdir -p "$OUT_DIR"
if [ ! -f "$OUT_DIR/.gitignore" ]; then
  echo "*" > "$OUT_DIR/.gitignore"
fi

say() { printf '\n\033[1m%s\033[0m\n' "$1"; }
pause() { read -r -p "Press Enter once that's done... " _; }

say "== Macless signing-secrets helper =="
echo "This writes files into ./$OUT_DIR/ — it's already gitignored, but"
echo "don't commit or share that folder anyway; it will contain real"
echo "signing secrets in base64 form."

# ---------------------------------------------------------------------
say "1/5 — Certificate Signing Request (SIGNING.md step 1)"
read -r -p "Your name (for the CSR): " CSR_NAME
read -r -p "Your email: " CSR_EMAIL

openssl genrsa -out "$OUT_DIR/dist.key" 2048
openssl req -new -key "$OUT_DIR/dist.key" -out "$OUT_DIR/dist.csr" \
  -subj "/emailAddress=$CSR_EMAIL, CN=$CSR_NAME, C=US"

echo "Wrote $OUT_DIR/dist.csr"
echo "Now: go to developer.apple.com/account/resources/certificates/list"
echo "-> + -> Apple Distribution -> upload $OUT_DIR/dist.csr -> download the .cer"
pause

# ---------------------------------------------------------------------
say "2/5 — Convert the downloaded certificate to a .p12 (SIGNING.md step 3)"
read -r -p "Path to the .cer file you just downloaded: " CER_PATH
read -r -s -p "Pick a password for the .p12 (you'll need this again as IOS_DIST_CERT_PASSWORD): " P12_PASSWORD
echo

openssl x509 -in "$CER_PATH" -inform DER -out "$OUT_DIR/distribution.pem" -outform PEM
openssl pkcs12 -export -inkey "$OUT_DIR/dist.key" -in "$OUT_DIR/distribution.pem" \
  -out "$OUT_DIR/dist.p12" -passout "pass:$P12_PASSWORD"
openssl base64 -in "$OUT_DIR/dist.p12" -out "$OUT_DIR/IOS_DIST_CERT_P12_BASE64.txt" -A

echo "Wrote $OUT_DIR/IOS_DIST_CERT_P12_BASE64.txt -> paste as secret IOS_DIST_CERT_P12_BASE64"
echo "(Password you picked -> paste as secret IOS_DIST_CERT_PASSWORD — not saved to a file, it's yours to remember/store.)"

# ---------------------------------------------------------------------
say "3/5 — Provisioning profile (SIGNING.md steps 4-5)"
echo "Now: register your App ID, then create an App Store distribution"
echo "profile for it at developer.apple.com/account/resources/profiles/list"
echo "-> download the .mobileprovision file."
pause

read -r -p "Path to the .mobileprovision file you just downloaded: " PROFILE_PATH
openssl base64 -in "$PROFILE_PATH" -out "$OUT_DIR/IOS_APP_PROVISION_PROFILE_BASE64.txt" -A
echo "Wrote $OUT_DIR/IOS_APP_PROVISION_PROFILE_BASE64.txt -> paste as secret IOS_APP_PROVISION_PROFILE_BASE64"

# ---------------------------------------------------------------------
say "4/5 — App Store Connect API key (SIGNING.md step 7)"
echo "Now: appstoreconnect.apple.com/access/api -> + -> role App Manager"
echo "-> download the .p8 file immediately (Apple only lets you once)"
echo "-> note the Key ID and Issuer ID shown on that page."
pause

read -r -p "Path to the downloaded .p8 file: " P8_PATH
openssl base64 -in "$P8_PATH" -out "$OUT_DIR/APPSTORE_API_PRIVATE_KEY_BASE64.txt" -A
echo "Wrote $OUT_DIR/APPSTORE_API_PRIVATE_KEY_BASE64.txt -> paste as secret APPSTORE_API_PRIVATE_KEY_BASE64"

read -r -p "Key ID shown on that page (paste as secret APPSTORE_API_KEY_ID): " KEY_ID
read -r -p "Issuer ID shown on that page (paste as secret APPSTORE_API_ISSUER_ID): " ISSUER_ID

# ---------------------------------------------------------------------
say "5/5 — Team ID (SIGNING.md step 8)"
read -r -p "Your Team ID from developer.apple.com/account -> Membership details (paste as secret APPLE_TEAM_ID): " TEAM_ID

# ---------------------------------------------------------------------
say "Done. Summary of what to paste into GitHub -> Settings -> Secrets and variables -> Actions:"
cat <<SUMMARY

Repository secrets:
  IOS_DIST_CERT_P12_BASE64        -> contents of $OUT_DIR/IOS_DIST_CERT_P12_BASE64.txt
  IOS_DIST_CERT_PASSWORD          -> the password you picked in step 2 (not saved to a file)
  IOS_APP_PROVISION_PROFILE_BASE64 -> contents of $OUT_DIR/IOS_APP_PROVISION_PROFILE_BASE64.txt
  APPSTORE_API_KEY_ID             -> $KEY_ID
  APPSTORE_API_ISSUER_ID          -> $ISSUER_ID
  APPSTORE_API_PRIVATE_KEY_BASE64 -> contents of $OUT_DIR/APPSTORE_API_PRIVATE_KEY_BASE64.txt
  APPLE_TEAM_ID                   -> $TEAM_ID

Repository variables (still yours to set — see SIGNING.md step 9):
  IOS_BUNDLE_ID
  IOS_PROVISIONING_PROFILE_NAME

Everything under $OUT_DIR/ is gitignored. Delete that folder once
you've pasted these into GitHub — there's no reason to keep plaintext
copies of your signing secrets sitting on disk longer than that.
SUMMARY
